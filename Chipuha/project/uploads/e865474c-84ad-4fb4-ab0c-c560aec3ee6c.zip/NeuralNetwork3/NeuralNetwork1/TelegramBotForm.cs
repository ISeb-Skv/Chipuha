﻿using System;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using NeuralNetwork1;
using Telegram.Bot;
using Telegram.Bot.Exceptions;
using Telegram.Bot.Types;
using Telegram.Bot.Types.Enums;
using File = System.IO.File;
using System.Linq;
using Telegram.Bot.Extensions;

// Явно указываем, какой Color используем
using DrawingColor = System.Drawing.Color;

namespace NeuralNetworkZodiac
{
    public partial class TelegramBotForm : Form
    {
        private TelegramBotClient botClient;
        private AIMLEngine aimlEngine;
        private BaseNetwork neuralNetwork;
        private bool isRunning = false;
        private CancellationTokenSource cancellationTokenSource;

        private TextBox tokenTextBox;
        private Button startButton;
        private Button stopButton;
        private TextBox logTextBox;
        private Label statusLabel;
        private Button loadNetworkButton;
        private Button saveLogButton;
        private PictureBox lastImageBox;
        private Label lastSignLabel;

        public TelegramBotForm()
        {
            InitializeComponent();
            aimlEngine = new AIMLEngine();

            string aimlPath = Path.Combine(Application.StartupPath, "aiml", "zodiac.aiml");
            if (File.Exists(aimlPath))
            {
                aimlEngine.LoadAIMLFile(aimlPath);
                LogMessage($"AIML загружен: {aimlPath}");
            }
            else
            {
                LogMessage($"AIML файл не найден: {aimlPath}");
            }
        }

        public void SetNeuralNetwork(BaseNetwork network)
        {
            neuralNetwork = network;
            LogMessage("Нейросеть передана боту");
        }

        private void InitializeComponent()
        {
            this.Text = "Telegram Бот для знаков зодиака";
            this.Size = new Size(900, 700);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Font = new Font("Segoe UI", 9);

            Panel controlPanel = new Panel
            {
                Location = new Point(10, 10),
                Size = new Size(870, 100),
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = DrawingColor.WhiteSmoke,
                Padding = new Padding(10)
            };

            Label tokenLabel = new Label
            {
                Text = "Токен бота:",
                Location = new Point(10, 15),
                Size = new Size(80, 25),
                TextAlign = ContentAlignment.MiddleLeft
            };

            tokenTextBox = new TextBox
            {
                Location = new Point(95, 15),
                Size = new Size(300, 25),
                Text = "ВАШ_ТОКЕН_ТУТ",
                Font = new Font("Segoe UI", 9)
            };

            startButton = new Button
            {
                Text = "🚀 ЗАПУСТИТЬ БОТА",
                Location = new Point(410, 15),
                Size = new Size(150, 30),
                BackColor = DrawingColor.FromArgb(76, 175, 80),
                Font = new Font("Segoe UI", 9, FontStyle.Bold),
                ForeColor = DrawingColor.White,
                FlatStyle = FlatStyle.Flat
            };
            startButton.FlatAppearance.BorderSize = 0;
            startButton.Click += StartButton_Click;

            stopButton = new Button
            {
                Text = "⛔ ОСТАНОВИТЬ",
                Location = new Point(570, 15),
                Size = new Size(150, 30),
                BackColor = DrawingColor.FromArgb(244, 67, 54),
                Font = new Font("Segoe UI", 9, FontStyle.Bold),
                ForeColor = DrawingColor.White,
                FlatStyle = FlatStyle.Flat,
                Enabled = false
            };
            stopButton.FlatAppearance.BorderSize = 0;
            stopButton.Click += StopButton_Click;

            loadNetworkButton = new Button
            {
                Text = "📁 ЗАГРУЗИТЬ СЕТЬ",
                Location = new Point(10, 55),
                Size = new Size(150, 30),
                BackColor = DrawingColor.FromArgb(33, 150, 243),
                Font = new Font("Segoe UI", 9, FontStyle.Bold),
                ForeColor = DrawingColor.White,
                FlatStyle = FlatStyle.Flat
            };
            loadNetworkButton.FlatAppearance.BorderSize = 0;
            loadNetworkButton.Click += LoadNetworkButton_Click;

            saveLogButton = new Button
            {
                Text = "💾 СОХРАНИТЬ ЛОГ",
                Location = new Point(170, 55),
                Size = new Size(150, 30),
                BackColor = DrawingColor.FromArgb(156, 39, 176),
                Font = new Font("Segoe UI", 9, FontStyle.Bold),
                ForeColor = DrawingColor.White,
                FlatStyle = FlatStyle.Flat
            };
            saveLogButton.FlatAppearance.BorderSize = 0;
            saveLogButton.Click += SaveLogButton_Click;

            statusLabel = new Label
            {
                Location = new Point(330, 55),
                Size = new Size(400, 30),
                Text = "Статус: Остановлен",
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleLeft,
                ForeColor = DrawingColor.Red
            };

            controlPanel.Controls.AddRange(new Control[]
            {
                tokenLabel, tokenTextBox, startButton, stopButton,
                loadNetworkButton, saveLogButton, statusLabel
            });

            Panel imagePanel = new Panel
            {
                Location = new Point(10, 120),
                Size = new Size(300, 200),
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = DrawingColor.White
            };

            lastImageBox = new PictureBox
            {
                Location = new Point(10, 10),
                Size = new Size(280, 150),
                BorderStyle = BorderStyle.FixedSingle,
                SizeMode = PictureBoxSizeMode.Zoom,
                BackColor = DrawingColor.Black
            };

            lastSignLabel = new Label
            {
                Location = new Point(10, 165),
                Size = new Size(280, 30),
                Text = "Последний знак: не распознан",
                Font = new Font("Segoe UI", 9),
                TextAlign = ContentAlignment.MiddleCenter
            };

            imagePanel.Controls.AddRange(new Control[] { lastImageBox, lastSignLabel });

            Panel logPanel = new Panel
            {
                Location = new Point(320, 120),
                Size = new Size(560, 530),
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = DrawingColor.White
            };

            Label logLabel = new Label
            {
                Text = "ЛОГ СООБЩЕНИЙ:",
                Location = new Point(10, 10),
                Size = new Size(540, 25),
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleLeft
            };

            logTextBox = new TextBox
            {
                Location = new Point(10, 40),
                Size = new Size(540, 480),
                Multiline = true,
                ScrollBars = ScrollBars.Vertical,
                Font = new Font("Consolas", 9),
                BackColor = DrawingColor.Black,
                ForeColor = DrawingColor.Lime,
                ReadOnly = true
            };

            logPanel.Controls.AddRange(new Control[] { logLabel, logTextBox });

            Panel infoPanel = new Panel
            {
                Location = new Point(10, 330),
                Size = new Size(300, 320),
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = DrawingColor.LightYellow,
                Padding = new Padding(10)
            };

            Label infoLabel = new Label
            {
                Text = "ИНФОРМАЦИЯ О БОТЕ:\n\n" +
                      "1. Получите токен у @BotFather в Telegram\n" +
                      "2. Вставьте токен в поле выше\n" +
                      "3. Загрузите обученную нейросеть\n" +
                      "4. Запустите бота кнопкой 'Запустить'\n\n" +
                      "Бот умеет:\n" +
                      "• Распознавать знаки зодиака по фото\n" +
                      "• Рассказывать о знаках зодиака\n" +
                      "• Запоминать имя пользователя\n" +
                      "• Помнить последний распознанный знак\n" +
                      "• Отвечать на вопросы о возможностях",
                Location = new Point(10, 10),
                Size = new Size(280, 300),
                Font = new Font("Segoe UI", 9)
            };

            infoPanel.Controls.Add(infoLabel);

            this.Controls.AddRange(new Control[]
            {
                controlPanel, imagePanel, logPanel, infoPanel
            });

            this.FormClosing += TelegramBotForm_FormClosing;
        }

        private async void StartButton_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(tokenTextBox.Text) || tokenTextBox.Text == "ВАШ_ТОКЕН_ТУТ")
            {
                MessageBox.Show("Введите токен бота!\n\nПолучите токен у @BotFather в Telegram:", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                botClient = new TelegramBotClient(tokenTextBox.Text);

                // Проверяем подключение - синхронный вариант
                var me = botClient.GetMe().Result;

                startButton.Enabled = false;
                stopButton.Enabled = true;
                tokenTextBox.Enabled = false;
                isRunning = true;

                statusLabel.Text = $"Статус: Запущен (@{me.Username})";
                statusLabel.ForeColor = DrawingColor.Green;

                LogMessage($"Бот запущен: {me.FirstName} (@{me.Username})");

                cancellationTokenSource = new CancellationTokenSource();

                // Используем старый подход с опросом для совместимости
                _ = Task.Run(() => ProcessUpdatesAsync(cancellationTokenSource.Token),
                    cancellationTokenSource.Token);
            }
            catch (ApiRequestException ex)
            {
                MessageBox.Show($"Ошибка API: {ex.Message}\nПроверьте токен бота.", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async Task ProcessUpdatesAsync(CancellationToken cancellationToken)
        {
            int offset = 0;

            while (!cancellationToken.IsCancellationRequested && isRunning)
            {
                try
                {
                    // Используем старый API совместимости
                    var updates = await botClient.GetUpdates(
                        offset: offset,
                        limit: 100,
                        timeout: 30,
                        cancellationToken: cancellationToken);

                    foreach (var update in updates)
                    {
                        offset = update.Id + 1;

                        if (update.Message != null)
                        {
                            await ProcessMessageAsync(update.Message, cancellationToken);
                        }
                    }

                    await Task.Delay(1000, cancellationToken);
                }
                catch (OperationCanceledException)
                {
                    break;
                }
                catch (Exception ex)
                {
                    LogMessage($"Ошибка при получении обновлений: {ex.Message}");
                    await Task.Delay(5000, cancellationToken);
                }
            }
        }

        private async Task ProcessMessageAsync(Telegram.Bot.Types.Message message, CancellationToken cancellationToken)
        {
            long chatId = message.Chat.Id;
            string userId = message.From?.Id.ToString() ?? "unknown";
            string userName = message.From?.FirstName ?? "Пользователь";

            try
            {
                if (message.Text != null)
                {
                    await HandleTextMessageAsync(message, chatId, userId, userName, cancellationToken);
                }
                else if (message.Photo != null && message.Photo.Length > 0)
                {
                    await HandlePhotoMessageAsync(message, chatId, userId, userName, cancellationToken);
                }
            }
            catch (Exception ex)
            {
                LogMessage($"Ошибка обработки сообщения: {ex.Message}");
                await botClient.SendMessage(
                    chatId: chatId,
                    text: "Произошла ошибка при обработке вашего сообщения.",
                    cancellationToken: cancellationToken);
            }
        }

        private async Task HandleTextMessageAsync(
            Telegram.Bot.Types.Message message,
            long chatId,
            string userId,
            string userName,
            CancellationToken cancellationToken)
        {
            string userMessage = message.Text ?? "";
            LogMessage($"[{userName}]: {userMessage}");

            aimlEngine.SetVariable("username", userName, userId);

            userMessage = userMessage.ToUpper().Replace('Ё', 'Е');
            string response = aimlEngine.ProcessInput(userMessage, userId);

            if (response.Contains("♈") || response.Contains("♉") || response.Contains("♊") ||
                response.Contains("♋") || response.Contains("♌") || response.Contains("♍") ||
                response.Contains("♎") || response.Contains("♏") || response.Contains("♐") ||
                response.Contains("♑") || response.Contains("♒") || response.Contains("♓"))
            {
                foreach (var signName in ZodiacSignHelper.GetAllRussianNames())
                {
                    if (response.Contains(signName))
                    {
                        aimlEngine.SetVariable("last_sign", signName, userId);
                        aimlEngine.LastSign = signName;
                        break;
                    }
                }
            }

            await botClient.SendMessage(
                chatId: chatId,
                text: response,
                parseMode: ParseMode.Html,
                cancellationToken: cancellationToken);

            LogMessage($"[Бот]: {response}");
        }

        private async Task HandlePhotoMessageAsync(
            Telegram.Bot.Types.Message message,
            long chatId,
            string userId,
            string userName,
            CancellationToken cancellationToken)
        {
            if (neuralNetwork == null)
            {
                await botClient.SendMessage(
                    chatId: chatId,
                    text: "Нейросеть для распознавания не загружена. Пожалуйста, обучите нейросеть в основном окне.",
                    cancellationToken: cancellationToken);
                return;
            }

            try
            {
                // Получаем последнее (самое качественное) фото
                var photo = message.Photo[message.Photo.Length - 1];
                var fileId = photo.FileId;

                // Получаем информацию о файле
                var file = await botClient.GetFile(fileId, cancellationToken);

                string tempPath = Path.GetTempFileName() + ".jpg";

                // Скачиваем файл - обычный using для совместимости
                using (var stream = new FileStream(tempPath, FileMode.Create))
                {
                    await botClient.DownloadFile(file.FilePath, stream, cancellationToken);
                }

                using (Bitmap image = new Bitmap(tempPath))
                {
                    // Обновляем PictureBox в UI потоке
                    this.Invoke(new Action(() =>
                    {
                        if (lastImageBox.Image != null)
                            lastImageBox.Image.Dispose();
                        lastImageBox.Image = new Bitmap(image);
                    }));

                    // Обрабатываем изображение
                    Bitmap processedImage = PreprocessImage(image);

                    // Конвертируем в вектор
                    double[] input = ConvertImageToVector(processedImage);

                    // Распознаем
                    Sample sample = new Sample(input, 12, ZodiacSign.Undef);
                    ZodiacSign predictedSign = neuralNetwork.Predict(sample);

                    string signName = predictedSign.ToRussianString();

                    // Сохраняем последний распознанный знак
                    aimlEngine.SetVariable("last_sign", signName, userId);
                    aimlEngine.LastSign = signName;

                    // Обновляем UI
                    this.Invoke(new Action(() =>
                    {
                        lastSignLabel.Text = $"Последний знак: {signName}";
                    }));

                    // Отправляем ответ
                    string response = $"Я распознал знак зодиака: {signName} ({predictedSign})!\n\n" +
                                     $"Теперь вы можете спросить меня об этом знаке, например:\n" +
                                     $"• \"Расскажи о {signName}\"\n" +
                                     $"• \"Что ещё ты знаешь о {signName}?\"\n" +
                                     $"• \"Какие характеристики у {signName}?\"";

                    await botClient.SendMessage(
                        chatId: chatId,
                        text: response,
                        cancellationToken: cancellationToken);

                    LogMessage($"[Бот]: Распознан знак: {signName}");

                    // Также отправляем эмодзи знака
                    string emoji = GetZodiacEmoji(predictedSign);
                    await botClient.SendMessage(
                        chatId: chatId,
                        text: $"{emoji} {signName} {emoji}",
                        cancellationToken: cancellationToken);
                }

                // Удаляем временный файл
                File.Delete(tempPath);
            }
            catch (Exception ex)
            {
                LogMessage($"Ошибка обработки фото: {ex.Message}");
                await botClient.SendMessage(
                    chatId: chatId,
                    text: "Произошла ошибка при обработке фотографии.",
                    cancellationToken: cancellationToken);
            }
        }

        private string GetZodiacEmoji(ZodiacSign sign)
        {
            switch (sign)
            {
                case ZodiacSign.Aries: return "♈";
                case ZodiacSign.Taurus: return "♉";
                case ZodiacSign.Gemini: return "♊";
                case ZodiacSign.Cancer: return "♋";
                case ZodiacSign.Leo: return "♌";
                case ZodiacSign.Virgo: return "♍";
                case ZodiacSign.Libra: return "♎";
                case ZodiacSign.Scorpio: return "♏";
                case ZodiacSign.Sagittarius: return "♐";
                case ZodiacSign.Capricorn: return "♑";
                case ZodiacSign.Aquarius: return "♒";
                case ZodiacSign.Pisces: return "♓";
                default: return "✨";
            }
        }

        private Bitmap PreprocessImage(Bitmap original)
        {
            Bitmap processed = new Bitmap(200, 200);

            using (Graphics g = Graphics.FromImage(processed))
            {
                g.Clear(DrawingColor.White);
                g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;

                float scale = Math.Min(180f / original.Width, 180f / original.Height);
                int newWidth = (int)(original.Width * scale);
                int newHeight = (int)(original.Height * scale);
                int offsetX = (200 - newWidth) / 2;
                int offsetY = (200 - newHeight) / 2;

                g.DrawImage(original, offsetX, offsetY, newWidth, newHeight);
            }

            // Конвертируем в черно-белое
            for (int x = 0; x < processed.Width; x++)
            {
                for (int y = 0; y < processed.Height; y++)
                {
                    DrawingColor pixel = processed.GetPixel(x, y);
                    int gray = (int)(pixel.R * 0.3 + pixel.G * 0.59 + pixel.B * 0.11);
                    processed.SetPixel(x, y, gray < 128 ? DrawingColor.Black : DrawingColor.White);
                }
            }

            return processed;
        }

        private double[] ConvertImageToVector(Bitmap image)
        {
            double[] vector = new double[400];

            for (int i = 0; i < 200; i++)
            {
                int rowSum = 0;
                int colSum = 0;
                for (int j = 0; j < 200; j++)
                {
                    DrawingColor pixelRow = image.GetPixel(i, j);
                    DrawingColor pixelCol = image.GetPixel(j, i);
                    if (pixelRow.R < 128) rowSum++;
                    if (pixelCol.R < 128) colSum++;
                }
                vector[i] = (double)rowSum / 200.0;
                vector[200 + i] = (double)colSum / 200.0;
            }

            return vector;
        }

        private void StopButton_Click(object sender, EventArgs e)
        {
            isRunning = false;

            if (cancellationTokenSource != null)
            {
                cancellationTokenSource.Cancel();
                cancellationTokenSource.Dispose();
                cancellationTokenSource = null;
            }

            startButton.Enabled = true;
            stopButton.Enabled = false;
            tokenTextBox.Enabled = true;

            statusLabel.Text = "Статус: Остановлен";
            statusLabel.ForeColor = DrawingColor.Red;

            LogMessage("Бот остановлен");
        }

        private void LoadNetworkButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Загрузите нейросеть в основном окне приложения, затем перезапустите Telegram бота.", "Информация",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void SaveLogButton_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveDialog = new SaveFileDialog
            {
                Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*",
                Title = "Сохранить лог",
                FileName = $"telegram_bot_log_{DateTime.Now:yyyyMMdd_HHmmss}.txt",
                DefaultExt = "txt"
            };

            if (saveDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    File.WriteAllText(saveDialog.FileName, logTextBox.Text);
                    MessageBox.Show($"Лог сохранен в файл:\n{saveDialog.FileName}", "Успех",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка сохранения лога: {ex.Message}", "Ошибка",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void LogMessage(string message)
        {
            if (logTextBox.InvokeRequired)
            {
                logTextBox.Invoke(new Action<string>(LogMessage), message);
                return;
            }

            string timestamp = DateTime.Now.ToString("HH:mm:ss");
            logTextBox.AppendText($"[{timestamp}] {message}\n");
            logTextBox.ScrollToCaret();
        }

        private void TelegramBotForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (isRunning)
            {
                if (MessageBox.Show("Бот все еще работает. Вы уверены, что хотите закрыть окно?", "Подтверждение",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.No)
                {
                    e.Cancel = true;
                    return;
                }

                StopButton_Click(null, null);
            }
        }
    }
}