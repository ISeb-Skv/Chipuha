﻿using System;
using System.Collections.Generic;
using System.Xml;
using System.Linq;
using System.Text.RegularExpressions;

namespace NeuralNetworkZodiac
{
    public class AIMLEngine
    {
        private Dictionary<string, List<AIMLCategory>> categories = new Dictionary<string, List<AIMLCategory>>();
        private Dictionary<string, string> userVariables = new Dictionary<string, string>();
        private Random random = new Random();
        private string lastSign = "";

        public string LastSign
        {
            get => lastSign;
            set => lastSign = value;
        }

        public class AIMLCategory
        {
            public string Pattern { get; set; }
            public string Template { get; set; }
            public bool IsWildcard { get; set; }
            public string Topic { get; set; }
        }

        public AIMLEngine()
        {
            // Инициализация базовых переменных
            SetVariable("username", "unknown");
            SetVariable("last_sign", "");
        }

        public void LoadAIMLFile(string filePath)
        {
            try
            {
                XmlDocument doc = new XmlDocument();
                doc.Load(filePath);

                XmlNamespaceManager nsmgr = new XmlNamespaceManager(doc.NameTable);
                nsmgr.AddNamespace("aiml", "http://alicebot.org/2001/AIML-1.0.1");

                var categoryNodes = doc.SelectNodes("//aiml:category", nsmgr);
                if (categoryNodes == null)
                {
                    categoryNodes = doc.SelectNodes("//category");
                }

                if (categoryNodes != null)
                {
                    foreach (XmlNode categoryNode in categoryNodes)
                    {
                        var patternNode = categoryNode.SelectSingleNode("pattern");
                        var templateNode = categoryNode.SelectSingleNode("template");

                        if (patternNode != null && templateNode != null)
                        {
                            string pattern = patternNode.InnerText.Trim().ToUpper();
                            string template = templateNode.InnerXml.Trim();

                            var category = new AIMLCategory
                            {
                                Pattern = pattern,
                                Template = template,
                                IsWildcard = pattern.Contains("*")
                            };

                            string firstWord = GetFirstWord(pattern);
                            if (!categories.ContainsKey(firstWord))
                            {
                                categories[firstWord] = new List<AIMLCategory>();
                            }
                            categories[firstWord].Add(category);
                        }
                    }
                }

                Console.WriteLine($"Загружено {categories.Sum(c => c.Value.Count)} категорий AIML");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка загрузки AIML файла: {ex.Message}");
            }
        }

        private string GetFirstWord(string pattern)
        {
            var words = pattern.Split(new[] { ' ', '*' }, StringSplitOptions.RemoveEmptyEntries);
            return words.Length > 0 ? words[0] : "*";
        }

        public string ProcessInput(string input, string userId)
        {
            try
            {
                input = input.Trim().ToUpper();
                if (string.IsNullOrEmpty(input))
                    return "Я не понял ваш вопрос. Можете повторить?";

                // Пытаемся найти точное соответствие
                string firstWord = GetFirstWord(input);
                if (categories.ContainsKey(firstWord))
                {
                    foreach (var category in categories[firstWord])
                    {
                        if (MatchesPattern(input, category.Pattern, out string starValue))
                        {
                            return ProcessTemplate(category.Template, starValue, userId);
                        }
                    }
                }

                // Проверяем категории с другими первыми словами
                foreach (var categoryList in categories.Values)
                {
                    foreach (var category in categoryList)
                    {
                        if (MatchesPattern(input, category.Pattern, out string starValue))
                        {
                            return ProcessTemplate(category.Template, starValue, userId);
                        }
                    }
                }

                // Проверяем категории с wildcard
                if (categories.ContainsKey("*"))
                {
                    foreach (var category in categories["*"])
                    {
                        if (MatchesPattern(input, category.Pattern, out string starValue))
                        {
                            return ProcessTemplate(category.Template, starValue, userId);
                        }
                    }
                }

                return "Извините, я не понял ваш вопрос. Я могу рассказать о знаках зодиака, которые я распознаю.";
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка обработки ввода: {ex.Message}");
                return "Произошла ошибка при обработке вашего запроса.";
            }
        }

        private bool MatchesPattern(string input, string pattern, out string starValue)
        {
            starValue = "";
            pattern = pattern.Trim().ToUpper();

            if (pattern == input)
                return true;

            if (pattern.Contains("*"))
            {
                string regexPattern = "^" + Regex.Escape(pattern).Replace("\\*", "(.*)") + "$";
                var match = Regex.Match(input, regexPattern);
                if (match.Success && match.Groups.Count > 1)
                {
                    starValue = match.Groups[1].Value;
                    return true;
                }
            }

            return false;
        }

        private string ProcessTemplate(string template, string starValue, string userId)
        {
            try
            {
                string result = template;

                // Обработка <star/>
                result = result.Replace("<star/>", starValue);

                // Обработка <get name="variable"/>
                result = ProcessGetTags(result, userId);

                // Обработка <set name="variable">value</set>
                result = ProcessSetTags(result, starValue, userId);

                // Обработка <srai>pattern</srai>
                result = ProcessSraiTags(result, userId);

                // Обработка <condition>
                result = ProcessConditionTags(result, starValue, userId);

                // Обработка <random> и <li>
                result = ProcessRandomTags(result);

                // Обработка <think>
                result = ProcessThinkTags(result, starValue, userId);

                // Удаление XML тегов и форматирование
                result = CleanXmlTags(result);

                return result.Trim();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка обработки шаблона: {ex.Message}");
                return "Произошла ошибка при формировании ответа.";
            }
        }

        private string ProcessGetTags(string text, string userId)
        {
            var matches = Regex.Matches(text, @"<get\s+name=""([^""]+)""\s*/>");
            foreach (Match match in matches)
            {
                string varName = match.Groups[1].Value;
                string varValue = GetVariable(varName, userId);
                text = text.Replace(match.Value, varValue);
            }
            return text;
        }

        private string ProcessSetTags(string text, string starValue, string userId)
        {
            var matches = Regex.Matches(text, @"<set\s+name=""([^""]+)"">([^<]*)</set>");
            foreach (Match match in matches)
            {
                string varName = match.Groups[1].Value;
                string varValue = match.Groups[2].Value;

                if (varValue == "<star/>")
                    varValue = starValue;

                SetVariable(varName, varValue, userId);
                text = text.Replace(match.Value, "");
            }
            return text;
        }

        private string ProcessSraiTags(string text, string userId)
        {
            var matches = Regex.Matches(text, @"<srai>([^<]+)</srai>");
            foreach (Match match in matches)
            {
                string pattern = match.Groups[1].Value;
                text = text.Replace(match.Value, ProcessInput(pattern, userId));
            }
            return text;
        }

        private string ProcessConditionTags(string text, string starValue, string userId)
        {
            var conditionMatch = Regex.Match(text, @"<condition\s+name=""([^""]+)"">(.*?)</condition>", RegexOptions.Singleline);
            if (conditionMatch.Success)
            {
                string varName = conditionMatch.Groups[1].Value;
                string conditionContent = conditionMatch.Groups[2].Value;
                string varValue = GetVariable(varName, userId);

                var liMatches = Regex.Matches(conditionContent, @"<li\s+value=""([^""]+)"">(.*?)</li>", RegexOptions.Singleline);
                foreach (Match liMatch in liMatches)
                {
                    string liValue = liMatch.Groups[1].Value;
                    string liContent = liMatch.Groups[2].Value;

                    if (varValue.ToUpper() == liValue.ToUpper() || (liValue == "unknown" && string.IsNullOrEmpty(varValue)))
                    {
                        return ProcessTemplate(liContent, starValue, userId);
                    }
                }

                // Проверяем последний <li> без значения (по умолчанию)
                var defaultLiMatch = Regex.Match(conditionContent, @"<li>(.*?)</li>", RegexOptions.Singleline);
                if (defaultLiMatch.Success)
                {
                    return ProcessTemplate(defaultLiMatch.Groups[1].Value, starValue, userId);
                }
            }

            return text;
        }

        private string ProcessRandomTags(string text)
        {
            var randomMatch = Regex.Match(text, @"<random>(.*?)</random>", RegexOptions.Singleline);
            if (randomMatch.Success)
            {
                string randomContent = randomMatch.Groups[1].Value;
                var liMatches = Regex.Matches(randomContent, @"<li>(.*?)</li>", RegexOptions.Singleline);

                if (liMatches.Count > 0)
                {
                    int index = random.Next(liMatches.Count);
                    return liMatches[index].Groups[1].Value.Trim();
                }
            }
            return text;
        }

        private string ProcessThinkTags(string text, string starValue, string userId)
        {
            var thinkMatch = Regex.Match(text, @"<think>(.*?)</think>", RegexOptions.Singleline);
            if (thinkMatch.Success)
            {
                string thinkContent = thinkMatch.Groups[1].Value;
                // Выполняем set внутри think, но не выводим результат
                ProcessSetTags(thinkContent, starValue, userId);
                // Удаляем think тег
                text = text.Replace(thinkMatch.Value, "");
            }
            return text;
        }

        private string CleanXmlTags(string text)
        {
            // Удаляем все оставшиеся XML теги
            text = Regex.Replace(text, @"<[^>]+>", "");
            // Заменяем HTML-сущности
            text = text.Replace("&lt;", "<").Replace("&gt;", ">").Replace("&amp;", "&");
            return text;
        }

        public void SetVariable(string name, string value, string userId = null)
        {
            string key = userId != null ? $"{userId}_{name}" : name;
            userVariables[key] = value;

            if (name == "last_sign")
            {
                LastSign = value;
            }
        }

        public string GetVariable(string name, string userId = null)
        {
            string key = userId != null ? $"{userId}_{name}" : name;
            return userVariables.ContainsKey(key) ? userVariables[key] : "";
        }

        public void ClearUserVariables(string userId)
        {
            var keysToRemove = userVariables.Keys.Where(k => k.StartsWith(userId + "_")).ToList();
            foreach (var key in keysToRemove)
            {
                userVariables.Remove(key);
            }
        }
    }
}