﻿namespace NeuralNetworkZodiac
{
}