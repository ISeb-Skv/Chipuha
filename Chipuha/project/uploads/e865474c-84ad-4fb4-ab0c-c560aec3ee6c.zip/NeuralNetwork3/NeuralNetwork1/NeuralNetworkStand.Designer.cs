﻿namespace NeuralNetworkZodiac
{

}

